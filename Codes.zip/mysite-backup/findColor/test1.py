def hello():
	print('hello world')

if __name__ == '__main__':
	main()