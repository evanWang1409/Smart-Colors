from django.contrib import admin
from .models import color,pic,userPhoto

# Register your models here.

admin.site.register(color)
admin.site.register(pic)
admin.site.register(userPhoto)