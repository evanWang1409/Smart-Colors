from django.apps import AppConfig


class FindcolorConfig(AppConfig):
    name = 'findColor'
